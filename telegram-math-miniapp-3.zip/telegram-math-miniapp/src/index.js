const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };
const json = (data, status=200) => new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/health') return json({ ok: true, service: 'telegram-math-miniapp' });
    if (url.pathname.startsWith('/api/')) {
      if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
      try {
        const user = await authenticate(request, env);
        if (!user) return json({ error: 'اعتبارسنجی تلگرام ناموفق است. برنامه را از داخل تلگرام باز کنید.' }, 401);
        const body = await request.json().catch(()=>({}));
        const gate = await checkSchoolAccess(user, body.accessCode, env);
        if (!gate.ok) return json({ error: 'کد دسترسی مدرسه معتبر نیست.', accessRequired: true }, 403);
        if (url.pathname === '/api/me') return await profile(user, env);
        if (url.pathname === '/api/progress') return await saveProgress(user, body, env);
        if (url.pathname === '/api/chat') return await chat(user, body, env);
        return json({ error: 'Not found' }, 404);
      } catch (err) {
        console.error('request failed', err?.message || err);
        return json({ error: 'خطای داخلی سرور' }, 500);
      }
    }
    return env.ASSETS.fetch(request);
  }
};

// Telegram WebApp initData HMAC validation (طبق مستندات رسمی تلگرام)
async function authenticate(request, env) {
  const raw = request.headers.get('X-Telegram-Init-Data') || '';
  if (!raw || !env.BOT_TOKEN) return null;
  const params = new URLSearchParams(raw);
  const hash = params.get('hash'); if (!hash) return null;
  params.delete('hash');
  const dataCheck = [...params.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');
  const enc = new TextEncoder();
  const secretKey = await crypto.subtle.importKey('raw', enc.encode('WebAppData'), {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
  const secret = await crypto.subtle.sign('HMAC', secretKey, enc.encode(env.BOT_TOKEN));
  const key = await crypto.subtle.importKey('raw', secret, {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
  const digest = new Uint8Array(await crypto.subtle.sign('HMAC', key, enc.encode(dataCheck)));
  const expected = [...digest].map(b=>b.toString(16).padStart(2,'0')).join('');
  if (!timingSafeEqual(hash, expected)) return null;
  const authDate = Number(params.get('auth_date'));
  if (!authDate || Math.abs(Date.now()/1000-authDate) > 86400) return null;
  let user; try { user = JSON.parse(params.get('user') || 'null'); } catch { return null; }
  if (!user?.id) return null;
  return { id: String(user.id), firstName: String(user.first_name || '').slice(0,80), lastName: String(user.last_name || '').slice(0,80), username: String(user.username || '').slice(0,80) };
}
function timingSafeEqual(a,b){ if(a.length!==b.length) return false; let out=0; for(let i=0;i<a.length;i++) out |= a.charCodeAt(i)^b.charCodeAt(i); return out===0; }
async function checkSchoolAccess(user, code, env) {
  if (!env.SCHOOL_ACCESS_CODE) return {ok:true};
  const stored = await env.DB.prepare('SELECT telegram_id FROM students WHERE telegram_id=?').bind(user.id).first();
  if (stored) return {ok:true};
  return {ok: typeof code==='string' && code.length<=128 && code===env.SCHOOL_ACCESS_CODE};
}
async function profile(user, env) {
  await env.DB.prepare(`INSERT INTO students (telegram_id, first_name, last_name, username, updated_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP) ON CONFLICT(telegram_id) DO UPDATE SET first_name=excluded.first_name,last_name=excluded.last_name,username=excluded.username,updated_at=CURRENT_TIMESTAMP`)
    .bind(user.id,user.firstName,user.lastName,user.username).run();
  const progress = await env.DB.prepare('SELECT COUNT(*) AS events FROM progress_events WHERE telegram_id=?').bind(user.id).first();
  return json({ok:true, student:{telegramId:user.id, firstName:user.firstName}, progress:{events:progress?.events||0}});
}
async function saveProgress(user, body, env) {
  const eventType = String(body.eventType || 'activity').slice(0,60);
  const safeDetail = JSON.stringify(body.detail && typeof body.detail==='object' ? body.detail : {}).slice(0,1000);
  await env.DB.prepare('INSERT INTO progress_events (telegram_id,event_type,detail_json,created_at) VALUES (?,?,?,CURRENT_TIMESTAMP)').bind(user.id,eventType,safeDetail).run();
  return json({ok:true});
}
async function chat(user, body, env) {
  const question = String(body.question || '').trim().slice(0,1500);
  if (!question) return json({error:'سوال خالی است.'},400);
  let answer;
  if (env.AI_API_URL && env.AI_API_KEY && env.AI_MODEL) {
    const response = await fetch(env.AI_API_URL, { method:'POST', headers:{'authorization':`Bearer ${env.AI_API_KEY}`,'content-type':'application/json'}, body:JSON.stringify({model:env.AI_MODEL, messages:[{role:'system',content:'تو یک آموزگار مهربان ریاضی پایه دهم هستی. به فارسی ساده و مرحله‌به‌مرحله درباره درصد، نسبت و تناسب پاسخ بده. اگر مسئله نامشخص است سؤال روشن‌کننده بپرس. اطلاعات شخصی دانش‌آموز را درخواست نکن.'},{role:'user',content:question}], temperature:0.3, max_tokens:500}) });
    if (!response.ok) throw new Error(`AI provider status ${response.status}`);
    const data=await response.json(); answer=data.choices?.[0]?.message?.content || 'پاسخی از سرویس هوش مصنوعی دریافت نشد.';
  } else answer = basicTutor(question);
  return json({ok:true,answer});
}
function basicTutor(q) {
  const normalized=q.replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));
  let m=normalized.match(/(\d+(?:\.\d+)?)\s*درصد\s*از\s*(\d+(?:\.\d+)?)/);
  if(m){const p=Number(m[1]),n=Number(m[2]);return `${p} درصد از ${n} برابر است با ${(p*n/100).toLocaleString('fa-IR')} . یعنی عدد را در درصد ضرب و بر ۱۰۰ تقسیم می‌کنیم.`;}
  m=normalized.match(/(\d+)\s*[:：]\s*(\d+)/);
  if(m){let a=+m[1],b=+m[2],g=gcd(a,b);return `نسبت ${a} به ${b} با تقسیم هر دو عدد بر ${g} ساده می‌شود: ${a/g} به ${b/g}. برای حفظ تناسب، هر دو طرف را در یک عدد یکسان ضرب یا بر آن تقسیم کن.`;}
  return 'برای حل دقیق، لطفاً سوال را با عددها بنویس؛ مثلاً «۲۰ درصد از ۲۵۰ چقدر است؟» یا «نسبت ۳ به ۶ را ساده کن». در این نسخه پاسخ‌گوی پایه فعال است؛ با تنظیم سرویس AI پاسخ‌گویی پیشرفته فعال می‌شود.';
}
function gcd(a,b){return b===0?a:gcd(b,a%b);}
